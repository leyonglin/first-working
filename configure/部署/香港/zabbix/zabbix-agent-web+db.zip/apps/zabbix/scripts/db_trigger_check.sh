#!/bin/bash
#####################
# filename: db_trigger_check.sh 
# auth: evan
# date: 2018-10-27

DB_BIN="/opt/apps/mysql/bin/mysql"
DB_USER="zabbixmonitor"
DB_SOCK="/opt/data/data_16303/mysql.sock"
DB_DATABASES="monitor"
TIME="1"

RESULT="`${DB_BIN} -u ${DB_USER} -S ${DB_SOCK} -e "select txt from ${DB_DATABASES}.trig_update_monitor where update_time >= DATE_SUB(NOW(),INTERVAL ${TIME} MINUTE) group by txt" | grep -v txt`"

case $1 in
  user_bet_bet_info)
    if [[ $RESULT =~ "警告user_bet表bet_info列有修改数据操作" ]];then
      echo 1
    else
      echo 0
    fi
    ;;
  user_bet_user_id)
    if [[ $RESULT =~ "警告user_bet表user_id列有修改数据操作" ]];then
      echo 1
    else
      echo 0
    fi
    ;;
  user_bet_account)
    if [[ $RESULT =~ "警告user_bet表account列有修改数据操作" ]];then
      echo 1
    else
      echo 0
    fi
    ;;
  user_bet_odds)
    if [[ $RESULT =~ "警告user_bet表odds列有修改数据操作" ]];then
      echo 1
    else
      echo 0
    fi
    ;;
  user_bet_total_money)
    if [[ $RESULT =~ "警告user_bet表total_money列有修改数据操作" ]];then
      echo 1
    else
      echo 0
    fi
    ;;
  user_bet_money)
    if [[ $RESULT =~ "警告user_bet表money列有修改数据操作" ]];then
      echo 1
    else
      echo 0
    fi
    ;;
  orders_userid)
    if [[ $RESULT =~ "警告orders表userid列有修改数据操作" ]];then
      echo 1
    else
      echo 0
    fi
    ;;
  orders_odds)
    if [[ $RESULT =~ "警告orders表odds列有修改数据操作" ]];then
      echo 1
    else
      echo 0
    fi
    ;;
  orders_ratio)
    if [[ $RESULT =~ "警告orders表ratio列有修改数据操作" ]];then
      echo 1
    else
      echo 0
    fi
    ;; 
  orders_league)
    if [[ $RESULT =~ "警告orders表league列有修改数据操作" ]];then
      echo 1
    else
      echo 0
    fi
    ;;
  orders_start)
    if [[ $RESULT =~ "警告orders表start列有修改数据操作" ]];then
      echo 1
    else
      echo 0
    fi
    ;;
  orders_settle_teamh)
    if [[ $RESULT =~ "警告orders表SettleTeamH列有修改数据操作" ]];then
      echo 1
    else
      echo 0
    fi
    ;;
  orders_settle_teamc)
    if [[ $RESULT =~ "警告orders表SettleTeamC列有修改数据操作" ]];then
      echo 1
    else
      echo 0
    fi
    ;;
  orders_rtype)
    if [[ $RESULT =~ "警告orders表RType列有修改数据操作" ]];then
      echo 1
    else
      echo 0
    fi
    ;;
  orders_sportstype)
    if [[ $RESULT =~ "警告orders表SportsType列有修改数据操作" ]];then
      echo 1
    else
      echo 0
    fi
    ;;
  orders_bettype)
    if [[ $RESULT =~ "警告orders表BetType列有修改数据操作" ]];then
      echo 1
    else
      echo 0
    fi
    ;; 
  orders_chuan_userid)
    if [[ $RESULT =~ "警告orders_chuan表userid列有修改数据操作" ]];then
      echo 1
    else
      echo 0
    fi
    ;;
  orders_chuan_odds)
    if [[ $RESULT =~ "警告orders_chuan表odds列有修改数据操作" ]];then
      echo 1
    else
      echo 0
    fi
    ;; 
  orders_chuan_ratio)
    if [[ $RESULT =~ "警告orders_chuan表ratio列有修改数据操作" ]];then
      echo 1
    else
      echo 0
    fi
    ;;
  orders_chuan_league)
    if [[ $RESULT =~ "警告orders_chuan表league列有修改数据操作" ]];then
      echo 1
    else
      echo 0
    fi
    ;;
  orders_chuan_start)
    if [[ $RESULT =~ "警告orders_chuan表start列有修改数据操作" ]];then
      echo 1
    else
      echo 0
    fi
    ;;
  orders_chuan_settleteamh)
    if [[ $RESULT =~ "警告orders_chuan表SettleTeamH列有修改数据操作" ]];then
      echo 1
    else
      echo 0
    fi
    ;;
  orders_chuan_settleteamc)
    if [[ $RESULT =~ "警告orders_chuan表SettleTeamC列有修改数据操作" ]];then
      echo 1
    else
      echo 0
    fi
    ;;
  orders_chuan_rtype)
    if [[ $RESULT =~ "警告orders_chuan表RType列有修改数据操作" ]];then
      echo 1
    else
      echo 0
    fi
    ;;
  orders_chuan_sportstype)
    if [[ $RESULT =~ "警告orders_chuan表SportsType列有修改数据操作" ]];then
      echo 1
    else
      echo 0
    fi
    ;;
  orders_chuan_bettype)
    if [[ $RESULT =~ "警告orders_chuan表BetType列有修改数据操作" ]];then
      echo 1
    else
      echo 0
    fi
    ;;
  user_bill)
    if [[ $RESULT =~ "user_bill表不允许update操作" ]];then
      echo 1
    else
      echo 0
    fi
    ;;
  recharge_order_history)
    if [[ $RESULT =~ "recharge_order_history表不允许update操作" ]];then
      echo 1
    else
      echo 0
    fi
    ;;
  *)
    echo "ERROR:USER db_trigger_check.sh (user_bet_bet_info|user_bet_user_id|user_bet_account|user_bet_odds|user_bet_total_money|user_bet_money|orders_userid|orders_odds|orders_ratio|orders_league|orders_start|orders_settle_teamh|orders_settle_teamc|orders_rtype|orders_sportstype|orders_bettype|orders_chuan_userid|orders_chuan_odds|orders_chuan_ratio|orders_chuan_league|orders_chuan_start|orders_chuan_settleteamh|orders_chuan_settleteamc|orders_chuan_rtype|orders_chuan_sportstype|orders_chuan_bettype|user_bill|recharge_order_history)"
    ;;
esac
