#/bin/sh
Device=$1
DISK=$2

case $DISK in
         rrqm_s)
            iostat -dxkt 1 2  | grep "\b$Device\b" | tail -1 |  awk '{print $2}'    #每秒读请求被合并次数
            ;;
         wrqm_s)
            iostat -dxkt 1 2  | grep "\b$Device\b" | tail -1 | awk '{print $3}'    #每秒写请求被合并次数
            ;;
         r_s)
            iostat -dxkt 1 2  | grep "\b$Device\b" | tail -1 | awk '{print $4}'     #每秒完成的读次数
            ;;
         w_s)
            iostat -dxkt 1 2  | grep "\b$Device\b" | tail -1 | awk '{print $5}'    #每秒完成的写次数
            ;;
         rkb_s)
            iostat -dxkt 1 2 | grep "\b$Device\b" | tail -1 | awk '{print $6}'    #每秒读数据量(kb)
            ;;
         wkb_s)
            iostat -dxkt 1 2 | grep "\b$Device\b" | tail -1 | awk '{print $7}'   #每秒写数据量(kb)
            ;;
         avgrq_sz)
            iostat -dxkt 1 2 | grep "\b$Device\b" | tail -1 | awk '{print $8}'     #平均每次IO请求的扇区大小
            ;;
         avgqu_sz)
            iostat -dxkt 1 2 | grep "\b$Device\b" | tail -1 | awk '{print $9}'      #平均每次IO请求的队列长度(越短越好)
            ;;
         await)
            iostat -dxkt 1 2 | grep "\b$Device\b" | tail -1 | awk '{print $10}'     #平均每次IO请求等待时间(毫秒)
            ;;
         r_await)
            iostat -dxkt 1 2 | grep "\b$Device\b" | tail -1 | awk '{print $11}'     #读的平均耗时(毫秒)
            ;;
         w_await)
            iostat -dxkt 1 2 | grep "\b$Device\b" | tail -1 | awk '{print $12}'     #写入平均耗时(毫秒)
            ;;
         svctm)
            iostat -dxkt 1 2 | grep "\b$Device\b" | tail -1 | awk '{print $13}'     #平均每次IO请求处理时间(毫秒)
            ;;
         util)
            iostat -dxkt 1 2 | grep "\b$Device\b" | tail -1 | awk '{print $14}'    #IO队列非空比例
            ;;
esac
