#!/bin/bash
# file_name: check_logs_date.sh
# auth: evan
# effect: 利用tomcat日志最后一个行时间判断tomcat是否正常运行


if [ $# -ne 1 ];then
    echo -e "\033[0;31mUSE: /bin/bash $0 {8002|7002|9002}\033[0m"
    exit 1
fi

# 截取当前最后一个日志时间
TOM_DATE=`tail -n 100 /opt/logs/tomcat/tomcat_${1}/catalina.out | awk -F '.' '{print $1}' | egrep "[0-9]{2}:[0-9]{2}:[0-9]{2}" | tail -n 1`

# 转化成时间戳
TOM_TIME=`date -d "${TOM_DATE}" +%s`

# 当前时间戳
NOW_TIME=`date '+%s'`

# 时间戳差
DIS=`expr ${NOW_TIME} - ${TOM_TIME}`

# 时间阈值
TIME_THRESHOLD=300

# 相差值小于300返回0，反之返回1
if [ ${DIS} -ge ${TIME_THRESHOLD} ];then
    echo 1
else
    echo 0
fi
