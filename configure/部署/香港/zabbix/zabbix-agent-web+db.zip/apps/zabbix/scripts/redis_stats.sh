#!/bin/bash
#--------------------------------------------------
# filename: redis_stats.sh
# auth: evan
# date: 2018-09-21

REDIS_CLI_COMMAND="/opt/apps/redis/bin/redis-cli"
REDIS_PORT="17693"
REDIS_PASSWD="9tN6GFGK60Jk8BNkBJM611GwA66uDFeG"

case $1 in
  # 当前连接数
  connected_clients)
    result=`$REDIS_CLI_COMMAND -p $REDIS_PORT -a $REDIS_PASSWD info | grep -w "connected_clients" | awk -F':' '{print $2}'`
    echo $result
    ;;
  # 当前已使用内存(byte)
  used_memory)
    result=`$REDIS_CLI_COMMAND -p $REDIS_PORT -a $REDIS_PASSWD info | grep -w "used_memory" | awk -F':' '{print $2}'`
    echo $result
    ;;
  # redis进程已分配内存大小(byte)
  used_memory_rss)
    result=`$REDIS_CLI_COMMAND -p $REDIS_PORT -a $REDIS_PASSWD info | grep -w "used_memory_rss" | awk -F':' '{print $2}'`
    echo $result
    ;;
  # 消耗内存峰值(byte)
  used_memory_peak)
    result=`$REDIS_CLI_COMMAND -p $REDIS_PORT -a $REDIS_PASSWD info | grep -w "used_memory_peak" | awk -F':' '{print $2}'`
    echo $result
    ;;
  # 已接受到的连接总数
  total_connections_received)
    result=`$REDIS_CLI_COMMAND -p $REDIS_PORT -a $REDIS_PASSWD info | grep -w "total_connections_received" | awk -F':' '{print $2}'`
    echo $result
    ;;
  # 每秒执行的命令数量
  instantaneous_ops_per_sec)
    result=`$REDIS_CLI_COMMAND -p $REDIS_PORT -a $REDIS_PASSWD info | grep -w "instantaneous_ops_per_sec" | awk -F':' '{print $2}'`
    echo $result
    ;;
  # 因最大连接数被拒绝的连接数量
  rejected_connections)
    result=`$REDIS_CLI_COMMAND -p $REDIS_PORT -a $REDIS_PASSWD info | grep -w "rejected_connections" | awk -F':' '{print $2}'`
    echo $result
    ;;
  # 因过期被自动删除的键值数量
  expired_keys)
    result=`$REDIS_CLI_COMMAND -p $REDIS_PORT -a $REDIS_PASSWD info | grep -w "expired_keys" | awk -F':' '{print $2}'`
    echo $result
    ;;
  # 因最大内存限制被evict的键值数量
  evicted_keys)
    result=`$REDIS_CLI_COMMAND -p $REDIS_PORT -a $REDIS_PASSWD info | grep -w "evicted_keys" | awk -F':' '{print $2}'`
    echo $result
    ;;
  # 查找键值成功次数
  keyspace_hits)
    result=`$REDIS_CLI_COMMAND -p $REDIS_PORT -a $REDIS_PASSWD info | grep -w "keyspace_hits" | awk -F':' '{print $2}'`
    echo $result
    ;;
  # 查找键值失败次数
  keyspace_misses)
    result=`$REDIS_CLI_COMMAND -p $REDIS_PORT -a $REDIS_PASSWD info | grep -w "keyspace_misses" | awk -F':' '{print $2}'`
    echo $result
    ;;
  # 请求命中率
  keyspace_hit_ratio)
    result_hits=`$REDIS_CLI_COMMAND -p $REDIS_PORT -a $REDIS_PASSWD info | grep -w "keyspace_hits" | awk -F':' '{print int($2)}'`
    result_misses=`$REDIS_CLI_COMMAND -p $REDIS_PORT -a $REDIS_PASSWD info | grep -w "keyspace_misses" | awk -F':' '{print int($2)}'`
    result_max=`expr $result_hits + $result_misses`
    result=`echo "$result_hits $result_max"| awk '{printf ("%0.2f\n",($1/$2)*100)}'`
    echo $result
    ;;
  # 正在等待，被阻塞的连接数
  blocked_clients)
    result=`$REDIS_CLI_COMMAND -p $REDIS_PORT -a $REDIS_PASSWD info | grep -w "blocked_clients" | awk -F':' '{print $2}'`
    echo $result
    ;;
  # 内存碎片比率
  mem_fragmentation_ratio)
    result=`$REDIS_CLI_COMMAND -p $REDIS_PORT -a $REDIS_PASSWD info | grep -w "mem_fragmentation_ratio" | awk -F':' '{print $2}'`
    echo $result
    ;;
  # db7键总数
  keys)
    result=`$REDIS_CLI_COMMAND -p $REDIS_PORT -a $REDIS_PASSWD info | grep -w 'db7:keys' | awk -F',' '{print $1}' | awk -F'=' '{print $2}'`
    echo $result
    ;;
  # 内存总量
  maxmemory)
    result=`$REDIS_CLI_COMMAND -p $REDIS_PORT -a $REDIS_PASSWD info | grep -w "maxmemory" | awk -F':' '{print $2}'`
    echo $result
    ;;
  # 内存使用率百分比
  used_memory_percentage)
    result_used=`$REDIS_CLI_COMMAND -p $REDIS_PORT -a $REDIS_PASSWD info | grep -w "used_memory" | awk -F':' '{print int($2)}'`
    result_max=`$REDIS_CLI_COMMAND -p $REDIS_PORT -a $REDIS_PASSWD info | grep -w "maxmemory" | awk -F':' '{print int($2)}'`
    result_over=`expr $result_max - $result_used`
    result=`echo "$result_over $result_max" | awk '{printf ("%0.2f\n",($1/$2)*100)}'`
    echo $result
    ;;
  *)
    echo "Usage:$0(connected_clients|used_memory_rss|used_memory_peak|userd_memory_ky|total_connections_received|instantaneous_ops_per_sec|rejected_connections|expired_keys|evicted_keys|keyspace_hits|keyspace_misses|keyspace_misses|keyspace_hit_ratio|blocked_clients|mem_fragmentation_ratio|maxmemory|used_memory_percentage)"
    ;;
esac
